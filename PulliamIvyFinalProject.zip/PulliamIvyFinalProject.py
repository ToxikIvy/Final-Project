import tkinter as tk
import os

fctextfile = "flashcards.txt"

# Loads your existing flashcards as long as there is a txt file named flashcards
def loadFlashcards(filename):
    flashcards = []
    if os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("|")
                if len(parts) == 2:
                    flashcards.append({"question": parts[0], "answer": parts[1]})
    return flashcards

# Saves the flashcards you created into an existing file named 'flashcards' so it can be used later
def saveAllFlashcards(filename, flashcards):
    with open(filename, "w", encoding="utf-8") as f:
        for card in flashcards:
            f.write(f"{card['question']}|{card['answer']}\n")

def appendFlashcard(filename, question, answer):
    with open(filename, "a", encoding="utf-8") as f:
        f.write(f"{question}|{answer}\n")

# Main display
class FlashcardApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Ivy's Flashcard App!")

        self.flashcards = loadFlashcards(fctextfile)
        self.current_card = 0
        self.flipped = False

        # Flashcard display and buttons
        self.card_frame = tk.Frame(root, padx=20, pady=20)
        self.card_frame.pack(pady=10)

        self.card_text = tk.Label(self.card_frame, text="", font=("Arial", 20), wraplength=400)
        self.card_text.pack()

        self.flip_button = tk.Button(root, text="Flip", command=self.flipCard)
        self.flip_button.pack(pady=5)

        self.next_button = tk.Button(root, text="Next", command=self.nextCard)
        self.next_button.pack(pady=5)

        self.delete_button = tk.Button(root, text="Delete", command=self.deleteFlashcard)
        self.delete_button.pack(pady=5)


        # Add a new flashcard
        self.entry_frame = tk.LabelFrame(root, text="Add New Flashcard", padx=10, pady=10, labelanchor="n", font=("Arial"))
        self.entry_frame.pack(pady=20)

        tk.Label(self.entry_frame, text="Question:").grid(row=0, column=0, sticky="e")
        self.question_entry = tk.Entry(self.entry_frame, width=40)
        self.question_entry.grid(row=0, column=1)

        tk.Label(self.entry_frame, text="Answer:").grid(row=1, column=0, sticky="e")
        self.answer_entry = tk.Entry(self.entry_frame, width=40)
        self.answer_entry.grid(row=1, column=1)

        self.save_button = tk.Button(self.entry_frame, text="Save Flashcard", command=self.saveFlashcard)
        self.save_button.grid(row=2, column=0, columnspan=2, pady=10)

        if self.flashcards:
            self.showQuestion()
        else:
            self.card_text.config(text="N/A")

    # Shows the question on the application
    def showQuestion(self):
        if not self.flashcards:
            self.card_text.config(text="N/A")
            return
        self.flipped = False
        question = self.flashcards[self.current_card]["question"]
        self.card_text.config(text=question)

    # Flips the question to show the answer
    def flipCard(self):
        if not self.flashcards:
            return
        if not self.flipped:
            answer = self.flashcards[self.current_card]["answer"]
            self.card_text.config(text=answer)
            self.flipped = True
        else:
            self.showQuestion()

    # Switches to the next flashcard
    def nextCard(self):
        if not self.flashcards:
            return
        self.current_card = (self.current_card + 1) % len(self.flashcards)
        self.showQuestion()

    # Saves the flashcard you created
    def saveFlashcard(self):
        question = self.question_entry.get().strip()
        answer = self.answer_entry.get().strip()
        if question and answer:
            self.flashcards.append({"question": question, "answer": answer})
            appendFlashcard(fctextfile, question, answer)
            self.question_entry.delete(0, tk.END)
            self.answer_entry.delete(0, tk.END)
            self.card_text.config(text="Flashcard saved")
        else:
            self.card_text.config(text="Please add more information")

    # Deletes a flashcard you don't need anymore
    def deleteFlashcard(self):
        if not self.flashcards:
            self.card_text.config(text="There are no flashcards to delete")
            return
        deleted_card = self.flashcards.pop(self.current_card)
        saveAllFlashcards(fctextfile, self.flashcards)
        if self.current_card >= len(self.flashcards):
            self.current_card = 0
        if self.flashcards:
            self.showQuestion()
        else:
            self.card_text.config(text="N/A")

if __name__ == "__main__":
    root = tk.Tk()
    app = FlashcardApp(root)
    root.mainloop()
